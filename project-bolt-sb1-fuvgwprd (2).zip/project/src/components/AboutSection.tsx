import React from 'react';
import { motion } from 'framer-motion';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-green-50">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-green-800 mb-6">About FreshVeggies</h2>
            <p className="text-gray-700 mb-4">
              Founded in 2023, FreshVeggies is on a mission to revolutionize how people access fresh, locally-grown vegetables in urban areas.
            </p>
            <p className="text-gray-700 mb-4">
              We partner directly with local farmers to source the freshest produce, cutting out middlemen and ensuring farmers receive fair compensation for their hard work.
            </p>
            <p className="text-gray-700 mb-4">
              Our unique 30-minute delivery promise within a 5km radius means you get farm-fresh vegetables at peak freshness, often harvested the same day they arrive at your doorstep.
            </p>
            <p className="text-gray-700">
              We're committed to sustainable practices, using eco-friendly packaging and electric delivery vehicles to minimize our environmental footprint.
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="grid grid-cols-2 gap-4"
          >
            <div className="aspect-square overflow-hidden rounded-lg">
              <img 
                src="https://images.unsplash.com/photo-1488459716781-31db52582fe9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" 
                alt="Vegetable farm" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-square overflow-hidden rounded-lg mt-8">
              <img 
                src="https://images.unsplash.com/photo-1595855759920-86582396756a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" 
                alt="Fresh vegetables" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-square overflow-hidden rounded-lg">
              <img 
                src="https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" 
                alt="Delivery" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-square overflow-hidden rounded-lg mt-8">
              <img 
                src="https://images.unsplash.com/photo-1607305387299-a3d9611cd469?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" 
                alt="Farmer" 
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
import React from 'react';
import { motion } from 'framer-motion';
import { Clock, MapPin, Truck, ShieldCheck } from 'lucide-react';

const DeliverySection: React.FC = () => {
  const features = [
    {
      icon: <Clock className="h-10 w-10 text-green-600" />,
      title: '30 Minute Delivery',
      description: 'We guarantee delivery within 30 minutes of placing your order, ensuring your vegetables are as fresh as possible.'
    },
    {
      icon: <MapPin className="h-10 w-10 text-green-600" />,
      title: '5km Radius Coverage',
      description: 'We currently serve customers within a 5km radius of our store to ensure quick and efficient delivery.'
    },
    {
      icon: <Truck className="h-10 w-10 text-green-600" />,
      title: 'Free Delivery',
      description: 'Enjoy free delivery on all orders with no minimum purchase required. We believe fresh vegetables should be accessible to all.'
    },
    {
      icon: <ShieldCheck className="h-10 w-10 text-green-600" />,
      title: 'Freshness Guarantee',
      description: "If you're not satisfied with the freshness of your vegetables, we'll replace them or refund your money."
    }
  ];

  return (
    <section id="delivery" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-green-800 mb-4">Lightning Fast Delivery</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We pride ourselves on our quick and reliable delivery service, bringing farm-fresh vegetables to your doorstep in no time.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-green-50 rounded-lg p-6 text-center"
            >
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-green-800 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-16 bg-green-600 rounded-xl overflow-hidden">
          <div className="grid md:grid-cols-2">
            <div className="p-8 md:p-12 flex flex-col justify-center">
              <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
                Download Our App for Even Faster Ordering
              </h3>
              <p className="text-green-100 mb-6">
                Get exclusive deals and track your delivery in real-time with our mobile app.
                Available for both iOS and Android devices.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-white text-green-600 px-6 py-3 rounded-lg font-medium hover:bg-green-100 transition-colors">
                  App Store
                </button>
                <button className="bg-white text-green-600 px-6 py-3 rounded-lg font-medium hover:bg-green-100 transition-colors">
                  Google Play
                </button>
              </div>
            </div>
            <div className="bg-green-700 p-8 md:p-12 flex items-center justify-center">
              <div className="w-full max-w-md h-[300px] bg-green-800 rounded-xl relative overflow-hidden">
                {/* This would be a phone mockup with the app */}
                <div className="absolute inset-0 flex items-center justify-center text-white text-xl font-bold">
                  App Preview
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DeliverySection;
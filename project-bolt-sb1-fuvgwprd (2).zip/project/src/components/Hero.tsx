import React from 'react';
import { motion } from 'framer-motion';
import { Clock, MapPin, Truck } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-green-50 to-white">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-green-600/20 to-transparent"></div>
      </div>
      
      <div className="container mx-auto px-4 z-10">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="text-left"
          >
            <h1 className="text-4xl md:text-6xl font-bold text-green-800 mb-4">
              Fresh Vegetables <br />
              <span className="text-green-600">Delivered to Your Door</span>
            </h1>
            <p className="text-lg text-gray-700 mb-6">
              Farm-fresh vegetables delivered within 30 minutes in your neighborhood.
              Support local farmers and enjoy the freshest produce.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <div className="flex items-center">
                <div className="bg-green-100 p-2 rounded-full mr-3">
                  <Clock className="h-5 w-5 text-green-600" />
                </div>
                <span className="text-gray-700">30 Min Delivery</span>
              </div>
              
              <div className="flex items-center">
                <div className="bg-green-100 p-2 rounded-full mr-3">
                  <MapPin className="h-5 w-5 text-green-600" />
                </div>
                <span className="text-gray-700">Within 5km Radius</span>
              </div>
              
              <div className="flex items-center">
                <div className="bg-green-100 p-2 rounded-full mr-3">
                  <Truck className="h-5 w-5 text-green-600" />
                </div>
                <span className="text-gray-700">Free Delivery</span>
              </div>
            </div>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-green-600 text-white px-8 py-3 rounded-full font-medium hover:bg-green-700 transition-colors"
            >
              Shop Now
            </motion.button>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative h-[400px] w-full"
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <div id="hero-3d-container" className="w-full h-full"></div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, useGLTF, Environment, Float } from '@react-three/drei';
import { Group } from 'three';

// Vegetable model component
const VegetableModel: React.FC<{ position: [number, number, number], rotation: [number, number, number], scale: number }> = ({ position, rotation, scale }) => {
  const group = useRef<Group>(null);
  
  useFrame((state) => {
    if (group.current) {
      group.current.rotation.y = state.clock.getElapsedTime() * 0.2;
    }
  });

  return (
    <group ref={group} position={position} rotation={rotation} scale={[scale, scale, scale]}>
      {/* This is a simple vegetable representation using basic shapes */}
      <mesh castShadow>
        <sphereGeometry args={[1, 32, 32]} />
        <meshStandardMaterial color="#4ade80" roughness={0.5} metalness={0.2} />
      </mesh>
      <mesh position={[0, 1.2, 0]} castShadow>
        <cylinderGeometry args={[0.2, 0.2, 1, 16]} />
        <meshStandardMaterial color="#15803d" roughness={0.8} />
      </mesh>
      <mesh position={[0, 1.8, 0]} castShadow>
        <coneGeometry args={[0.5, 0.8, 16]} />
        <meshStandardMaterial color="#16a34a" roughness={0.7} />
      </mesh>
    </group>
  );
};

// Scene component with multiple vegetables
const VegetableScene: React.FC = () => {
  return (
    <Canvas shadows camera={{ position: [0, 2, 5], fov: 50 }}>
      <ambientLight intensity={0.5} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
      <Environment preset="sunset" />
      
      <Float speed={1.5} rotationIntensity={0.5} floatIntensity={0.5}>
        <VegetableModel position={[-2, 0, 0]} rotation={[0, 0, 0]} scale={0.8} />
      </Float>
      
      <Float speed={2} rotationIntensity={0.7} floatIntensity={0.5}>
        <VegetableModel position={[0, 0, 0]} rotation={[0, Math.PI / 4, 0]} scale={1} />
      </Float>
      
      <Float speed={1.8} rotationIntensity={0.6} floatIntensity={0.5}>
        <VegetableModel position={[2, 0, 0]} rotation={[0, -Math.PI / 4, 0]} scale={0.9} />
      </Float>
      
      <OrbitControls enableZoom={false} enablePan={false} />
    </Canvas>
  );
};

export default VegetableScene;
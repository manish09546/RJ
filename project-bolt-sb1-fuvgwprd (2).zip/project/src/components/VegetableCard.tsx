import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Star } from 'lucide-react';

interface VegetableCardProps {
  name: string;
  price: number;
  unit: string;
  rating: number;
  image: string;
}

const VegetableCard: React.FC<VegetableCardProps> = ({ name, price, unit, rating, image }) => {
  return (
    <motion.div 
      whileHover={{ y: -10, transition: { duration: 0.3 } }}
      className="bg-white rounded-xl shadow-md overflow-hidden"
    >
      <div className="h-48 overflow-hidden">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
        />
      </div>
      <div className="p-4">
        <div className="flex items-center mb-2">
          {[...Array(5)].map((_, i) => (
            <Star 
              key={i} 
              className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
            />
          ))}
          <span className="text-xs text-gray-500 ml-1">({rating.toFixed(1)})</span>
        </div>
        <h3 className="font-semibold text-lg text-gray-800">{name}</h3>
        <div className="flex justify-between items-center mt-2">
          <div>
            <span className="text-green-600 font-bold">${price.toFixed(2)}</span>
            <span className="text-gray-500 text-sm ml-1">/ {unit}</span>
          </div>
          <button className="bg-green-600 text-white p-2 rounded-full hover:bg-green-700 transition-colors">
            <Plus className="h-5 w-5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default VegetableCard;
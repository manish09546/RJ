import React from 'react';
import VegetableCard from './VegetableCard';
import { motion } from 'framer-motion';

const categories = [
  'All', 'Leafy Greens', 'Root Vegetables', 'Gourds', 'Exotic', 'Organic'
];

const vegetables = [
  {
    id: 1,
    name: 'Fresh Spinach',
    price: 2.99,
    unit: 'bunch',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
    category: 'Leafy Greens'
  },
  {
    id: 2,
    name: 'Organic Carrots',
    price: 1.99,
    unit: 'kg',
    rating: 4.5,
    image: 'https://images.unsplash.com/photo-1447175008436-054170c2e979?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
    category: 'Root Vegetables'
  },
  {
    id: 3,
    name: 'Red Tomatoes',
    price: 3.49,
    unit: 'kg',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
    category: 'Gourds'
  },
  {
    id: 4,
    name: 'Green Bell Peppers',
    price: 2.49,
    unit: 'kg',
    rating: 4.3,
    image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
    category: 'Gourds'
  },
  {
    id: 5,
    name: 'Broccoli',
    price: 3.99,
    unit: 'head',
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
    category: 'Leafy Greens'
  },
  {
    id: 6,
    name: 'Purple Cabbage',
    price: 2.79,
    unit: 'head',
    rating: 4.4,
    image: 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
    category: 'Leafy Greens'
  },
  {
    id: 7,
    name: 'Sweet Potatoes',
    price: 1.89,
    unit: 'kg',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1596097635121-14b38c5d7eca?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
    category: 'Root Vegetables'
  },
  {
    id: 8,
    name: 'Zucchini',
    price: 2.29,
    unit: 'kg',
    rating: 4.2,
    image: 'https://images.unsplash.com/photo-1587334207810-d0fb57c7c3e9?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80',
    category: 'Gourds'
  }
];

const VegetableSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = React.useState('All');
  
  const filteredVegetables = activeCategory === 'All' 
    ? vegetables 
    : vegetables.filter(veg => veg.category === activeCategory);

  return (
    <section id="vegetables" className="py-16 bg-green-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-green-800 mb-4">Our Fresh Vegetables</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Browse our selection of farm-fresh vegetables, harvested daily and delivered to your doorstep within 30 minutes.
          </p>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 mb-10">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeCategory === category
                  ? 'bg-green-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-green-100'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
        
        <motion.div 
          layout
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
        >
          {filteredVegetables.map((vegetable) => (
            <motion.div
              key={vegetable.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              layout
            >
              <VegetableCard
                name={vegetable.name}
                price={vegetable.price}
                unit={vegetable.unit}
                rating={vegetable.rating}
                image={vegetable.image}
              />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default VegetableSection;
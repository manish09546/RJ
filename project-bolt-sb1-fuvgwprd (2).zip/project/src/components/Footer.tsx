import React from 'react';
import { Leaf, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-green-800 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <Leaf className="h-8 w-8 mr-2" />
              <span className="font-bold text-xl">FreshVeggies</span>
            </div>
            <p className="text-green-200 mb-4">
              Farm-fresh vegetables delivered to your doorstep within 30 minutes.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-green-200">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-green-200">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-green-200">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-green-200">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-green-200 hover:text-white">Home</a></li>
              <li><a href="#vegetables" className="text-green-200 hover:text-white">Vegetables</a></li>
              <li><a href="#about" className="text-green-200 hover:text-white">About Us</a></li>
              <li><a href="#delivery" className="text-green-200 hover:text-white">Delivery</a></li>
              <li><a href="#contact" className="text-green-200 hover:text-white">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">Delivery Areas</h3>
            <ul className="space-y-2">
              <li className="text-green-200">Downtown</li>
              <li className="text-green-200">Westside</li>
              <li className="text-green-200">Northpark</li>
              <li className="text-green-200">Eastville</li>
              <li className="text-green-200">Southend</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">Contact Us</h3>
            <address className="not-italic text-green-200">
              <p>123 Garden Street</p>
              <p>Veggieville, VG 12345</p>
              <p className="mt-2">hello@freshveggies.com</p>
              <p>+1 (555) 123-4567</p>
            </address>
          </div>
        </div>
        
        <div className="border-t border-green-700 mt-8 pt-8 text-center text-green-300">
          <p>&copy; {new Date().getFullYear()} FreshVeggies. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
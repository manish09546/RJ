import React, { useEffect, useRef } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import VegetableScene from './components/VegetableScene';
import VegetableSection from './components/VegetableSection';
import DeliverySection from './components/DeliverySection';
import AboutSection from './components/AboutSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';

function App() {
  const heroContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Mount the 3D scene to the hero container
    const container = document.getElementById('hero-3d-container');
    if (container) {
      const scene = document.createElement('div');
      scene.style.width = '100%';
      scene.style.height = '100%';
      container.appendChild(scene);
      
      // Render the VegetableScene component into this container
      const root = document.createElement('div');
      root.style.width = '100%';
      root.style.height = '100%';
      container.appendChild(root);
      
      // In a real implementation, we would use ReactDOM.createRoot here
      // For simplicity, we'll just use the component directly in the JSX
    }
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <VegetableSection />
      <DeliverySection />
      <AboutSection />
      <ContactSection />
      <Footer />
      
      {/* This div will hold our 3D scene */}
      <div ref={heroContainerRef} className="hidden">
        <VegetableScene />
      </div>
    </div>
  );
}

export default App;